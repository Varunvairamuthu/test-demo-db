const mongoose = require('mongoose');


const resultSchema = new mongoose.Schema({

    name:{
        type:String,
        required:false,
    },
    semester:{
        type:String,
        required:false
    },
    pass:{
        type:String,
        required:false
    },
    fail:{
        type:String,
        required:false
    },
    
})

const result = mongoose.model('result', resultSchema)
module.exports = result;