const mongoose = require('mongoose');
const { collection } = require('../student/studentnodel');
// const opts = {
//     createdAt: "created_at",
//     updatedAt: "updated_at",
//   };
const netflixSchema = new mongoose.Schema ({

    Title : {
        type:String,
        required:false,
    },   
    posterpath:{
        type:String,
        required:false,
    },
    avg_vote :{
        type:String,
        required:false,
    },
    Overview: {
        type:String,
        required:false,
    },
    Releasedate:{
        type:String,
        required:false,
    },
    adult: {
        type:Boolean,
        required:false,
    },
    back_drop_path:{
        type:String,
        required:false,
    },
    Orginal_Length:{
        type:String,
        required:false,
    },
    Media_type:{
        type:String,
        required:false,
    },
    Trailer_Link :{
        type:String,
        required:false,
    },
    Cast:{
        type:String,
        required:false,
    },
    ActivityDateTime:{
        type:String,
        required:false,
     default: Date.now,
        
    },
  
    
});

// netflixSchema.set('timestamps', true);

// x=Date.now()
// console.log(x)
//  var a = new Date(x).toString()
//  console.log(a)
  



// //current timestamp in milliseconds


// let x = new Date(ActivityDateTime);
// let date = x.getDate();
// let month = x.getMonth();
// let year = x.getFullYear();

// // //prints date & time in YYYY-MM-DD format
// console.log(year.toString + "-" + month.toString + "-" + date.toString);


// var current_timestamp = new Date();
// postman.ActivityDateTime("current_timestamp", current_timestamp.toISOString());
// console.log("postman")
module.exports= mongoose.model('netflix', netflixSchema);  
// const netflix = mongoose.model("User", userSchema);

// const doc = await netflix.create({netflixSchema });
// doc.createdAt; 
// doc.updatedAt; 

// doc.createdAt instanceof Date;