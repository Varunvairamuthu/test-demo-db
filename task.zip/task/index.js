const express = require ('express');
const mongoose = require ('mongoose');
const cors = require('cors');
const app = express();
//import router file
 const student  = require('./student/studentrouterl')
 const result = require('./result/resultrouter')
 const perform = require('./perform/performrouter')
 const netflix = require('./netflix/netflixrouter')
app.use(express.json())
app.use(cors())
port = 5000

mongoose.connect('mongodb+srv://12345muthu:12345muthu@cluster0.8dyy3.mongodb.net/studentdatabase',(req,res)=>{
    try {
        console.log('mongodb connected')    
    } catch (error) {
        console.log|(error)
        
    }
})

//declare routers
app.use('/student', student)
app.use('/result', result)
app.use('/perform', perform)
app.use('/netflix', netflix)
app.listen(port, ()=>{
    console.log( 'local host connectd')
})




