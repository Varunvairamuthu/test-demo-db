const mongoose = require('mongoose');


const performSchema = new mongoose.Schema({

    name:{
        type:String,
        required:false,
    },
    semester:{
        type:String,
        required:false
    },
    edup:{
        type:String,
        required:false
    },
    personalactivities: {
        type:String,
        required:false
    },
    
})

const Perform = mongoose.model('Perform', performSchema)
module.exports = Perform;