const express = require('express');
const Post = require('./performnod')

const router = express.Router();

// get

router.get('/', async(req, res, next)=>{
    const post = await Post.find()
    res.status(200).json({
        sucess:true,
        data:post
    })
});
// post

router.post('/', async(req, res, next)=>{

    try {
        const post = await Post.create(req.body)
        res.status(200).json({
            sucess:true,
            data:post
        })
    } catch (error) {
        res.status(500).json({
            sucess:false,
            
        })
    }
   
});
// single object get 
router.get('/:id', async(req, res, next)=>{
    const post = await Post.findById(req.params.id)
    res.json({
        data:post
    })
});

// name 
router.get('name/:name', async(req, res, next)=>{
    const post = await Post.findById(req.params.name)
    res.json({
        data:post
    })
});

//put 
router.put('/:id', async(req, res, next)=>{
    const post = await Post.findByIdAndUpdate(req.params.id,req.body)
    res.json({
        data:post
    })
});

//delete
router.delete('/:id', async(req, res, next)=>{
    const post = await Post.findByIdAndDelete(req.params.id)
    res.json({
        delete:true
    })
})

module.exports = router;